//
//  Animal+CoreDataClass.swift
//  Projekt_TW_GL10
//
//  Created by student on 06/06/2022.
//  Copyright © 2022 pl. All rights reserved.
//
//

import Foundation
import CoreData


public class Animal: NSManagedObject {

}
