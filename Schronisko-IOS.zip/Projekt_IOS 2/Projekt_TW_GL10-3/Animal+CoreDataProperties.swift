//
//  Animal+CoreDataProperties.swift
//  Projekt_TW_GL10
//
//  Created by student on 19/06/2022.
//  Copyright © 2022 pl. All rights reserved.
//
//

import Foundation
import CoreData


extension Animal {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Animal> {
        return NSFetchRequest<Animal>(entityName: "Animal")
    }

    @NSManaged public var age: Int16
    @NSManaged public var breed: String?
    @NSManaged public var colour: String?
    @NSManaged public var date_admission: Date?
    @NSManaged public var name: String?
    @NSManaged public var sex: Bool
    @NSManaged public var type: String?
    @NSManaged public var typ: Type?

}

extension Animal : Identifiable {

}
