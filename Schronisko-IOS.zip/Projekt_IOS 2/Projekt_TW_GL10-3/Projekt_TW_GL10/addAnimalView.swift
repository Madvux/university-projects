import CoreData
import SwiftUI
import Combine

struct addAnimalView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath:
        \Animal.name, ascending: true)], animation: .default)
    private var animals: FetchedResults<Animal>

    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath:
        \Type.name, ascending: true)], animation: .default)
    private var types: FetchedResults<Type>

    @State private var name: String = ""
    @State private var sex: Bool = false
    @State private var date_admission: Date = Date()
    @State private var breed: String = ""
    @State private var colour: String = ""
    @State private var age: String = ""
    @State private var type: Type?
    @Environment(\.presentationMode) private var presentationMode: Binding<PresentationMode>
    
    
    var body: some View {
        VStack{
            Text("Dodaj zwierze")
                .font(.largeTitle)
            if (types.isEmpty){
                Button("Dodaj typy zwierzat"){self.initTypes()}
            }
            Form
            {
                Picker(selection: $type,
                    label: Text("Wybierz typ zwierzecia")){
                    ForEach(types, id: \.self) { (type: Type) in
                    Text(type.name!).tag(type as Type?)
                    }}.padding()
            TextField("Name:",text: $name).padding()
                DatePicker(selection: $date_admission, in: ...Date(), displayedComponents: .date){
                    Text("Data przyjecia do schroniska")
                }.padding()
            Toggle(isOn: $sex){
                    if (sex == true) {Text("Samiec")}
                    else{Text("Samica")}
            }.padding()
                
            TextField("Rasa:",text: $breed).padding()

            TextField("Kolor:",text: $colour).padding()
            TextField("Wiek:",text: $age).padding()
                    .keyboardType(.numberPad)
                    .onReceive(Just(age)) {
                        newValue in
                        let filtered = newValue.filter{"0123456789".contains($0)}
                        if filtered != newValue {
                            self.age = filtered
                        }
                        }
                    
                    HStack{
                    Spacer()
                Button("Dodaj zwierzę"){
                    self.addAnimal()
                    self.presentationMode.wrappedValue.dismiss()
                }
                    Spacer()
            }
                
            }
        }
    }
    
    private func initTypes(){
        
        let newType1 = Type(context: viewContext)
            newType1.name = "Pies"
        
        let newType2 = Type(context: viewContext)
            newType2.name = "Kot"
        
        let newType3 = Type(context: viewContext)
            newType3.name = "Inne"

        do {
            try viewContext.save()
        }
        catch {
            let err = error as NSError
            fatalError("\(err)")
        }
}
private func addAnimal(){
       let newAnimal = Animal(context: viewContext)
        newAnimal.sex = sex
    if (name.isEmpty){ newAnimal.name = "Nie podano imienia" }
    else{newAnimal.name = name}
    if (breed.isEmpty){ newAnimal.breed = "Brak informacji o rasie" }
    else{newAnimal.breed = breed}
    newAnimal.date_admission = date_admission
    if (colour.isEmpty) {newAnimal.colour = "Brak informacji o kolorze"}
    else{ newAnimal.colour = colour }

    if (type?.name == nil) {newAnimal.type = "Inne"}
    else{ newAnimal.type = type?.name }
    
    if (age.isEmpty){
        newAnimal.age = -1
    }
    else{newAnimal.age = Int16(age)!}
       
       do {
           try viewContext.save()
       }
       catch {
           let err = error as NSError
           fatalError("\(err)")
       }
   }
}

