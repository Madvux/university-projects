//
//  ContentView.swift
//  Projekt_TW_GL10
//
//  Created by student on 06/06/2022.
//  Copyright © 2022 pl. All rights reserved.
//

import CoreData
import SwiftUI
import MapKit

class MyAnnotation: NSObject, MKAnnotation {
    var title: String?
    var subtitle: String?
    var coordinate: CLLocationCoordinate2D
    
    init(title: String?, subtitle: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.subtitle = title
        self.coordinate = coordinate
    }
}

struct MapView: UIViewRepresentable {
    @Binding var myAnnotation: MyAnnotation
    
    func makeUIView(context: UIViewRepresentableContext<MapView>) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        return mapView
    }
    
    func updateUIView(_ uiView: MKMapView, context: UIViewRepresentableContext<MapView>) {
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center:
        myAnnotation.coordinate, span: span)
        uiView.setRegion(region, animated: true)
        uiView.addAnnotations([myAnnotation])
    }
}

struct ContentView: View {
    
    @State var myAnnotation = MyAnnotation(title: "Nasza lokacja", subtitle: "Schronisko dla zwierząt",
        coordinate: CLLocationCoordinate2D(latitude:51.2353112433304, longitude: 22.55289822681853))
    

    
    var body: some View {
        NavigationView{
            VStack{
                Image("LOGO")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150, alignment: .center)
                    .clipShape(Circle())

                Text("Schronisko dla Zwiarząt")
                    .font(.largeTitle)
                    .padding()
                Text("Nadbystrzycka 32b, 20-230 Lublin")
                    .font(.headline)
                Text("999-333-222")
                    .font(.headline)
                
                MapView(myAnnotation: $myAnnotation)
                .gesture(TapGesture()
                    .onEnded(){
                    })
                .frame(maxWidth: .infinity)
                .frame(height: 300)
                .padding()
                
                NavigationLink(
                    destination: ListView(), label: {
                        Text("Przeszukaj zwierzeta")
                            .font(.title).multilineTextAlignment(.center)
                        .frame(width: 200, height: 80)
                }
                )
                Spacer()
            }
            }.navigationBarTitle("Schronisko dla zwierzat")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
