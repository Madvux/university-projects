import CoreData
import SwiftUI
import Combine

struct editAnimalView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath:
        \Animal.name, ascending: true)], animation: .default)
    private var animals: FetchedResults<Animal>
    
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath:
        \Type.name, ascending: true)], animation: .default)
    private var types: FetchedResults<Type>
    
    @State private var name: String = ""
    @State private var breed: String = ""
    @State private var colour: String = ""
    @State private var age: String = ""
    @State private var type: Type?
    @Environment(\.presentationMode) private var presentationMode: Binding<PresentationMode>
    
    var animal:Animal
    var body: some View {
        VStack{
            Text("Edytuj informacje")
                .font(.largeTitle)
            
            if (UIImage(named: animal.breed!.capitalized) != nil){
                Image(animal.breed!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200, alignment: .center)
                    .clipShape(Circle())            }
            else if (UIImage(named: animal.type!) != nil){
                Image(animal.type!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200, alignment: .center)
                    .clipShape(Circle())            }
            else {Image("LOGO")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200, alignment: .center)
                    .clipShape(Circle())            }
            if (types.isEmpty){
                Button("Dodaj typy zwierzat"){self.initTypes()}
            }
            Form
            {
                Picker(selection: $type, label: Text(animal.type ?? "Brak informacji").font(.headline)){
                    ForEach(types, id: \.self) { (type: Type) in
                    Text(type.name!).tag(type as Type?)
                    }}.padding()
            TextField(animal.name ?? "Imie psa:", text: $name).padding()
                
                DatePicker(selection: Binding<Date>(
                    get: {self.animal.date_admission ?? Date()},
                    set: {self.animal.date_admission = $0
                        try? self.viewContext.save()
                    }), in: ...Date(), displayedComponents: .date){
                    Text("Data przyjecia do schroniska")
                }.padding()
                
                Toggle(isOn: Binding<Bool>(
                    get: {self.animal.sex},
                    set: {
                        self.animal.sex = $0
                        try? self.viewContext.save()
                    })){
                        if (animal.sex == true) {Text("Samiec")}
                        else{Text("Samica")}
                    }.padding()
            TextField(animal.breed ?? "Rasa:", text: $breed).padding()
            TextField(animal.colour ?? "Kolor:",text: $colour).padding()
                TextField(String(animal.age) ,text: $age).padding()
                    .keyboardType(.numberPad)
                    .onReceive(Just(age)) {
                        newValue in
                        let filtered = newValue.filter{"0123456789".contains($0)}
                        if filtered != newValue {
                            self.age = filtered
                        }
                        }
                
                    HStack{
                    Spacer()
                Button("Zapisz"){
                    if (!self.name.isEmpty) {self.animal.name = self.name}
                    if (!self.age.isEmpty) {self.animal.age = Int16(self.age)!}
                    if (!self.breed.isEmpty) {self.animal.breed = self.breed}
                    if (!self.colour.isEmpty) {self.animal.colour = self.colour}
                    if (self.type != nil) {self.animal.type = self.type?.name}
                    self.editAnimal()
                    self.presentationMode.wrappedValue.dismiss()
                }
                Spacer()
            }
                
            }
        }
    }
    
    private func initTypes(){
        
        let newType1 = Type(context: viewContext)
            newType1.name = "Pies"
        
        let newType2 = Type(context: viewContext)
            newType2.name = "Kot"
        
        let newType3 = Type(context: viewContext)
            newType3.name = "Inne"

        do {
            try viewContext.save()
        }
        catch {
            let err = error as NSError
            fatalError("\(err)")
        }
}
    
private func editAnimal(){
       do {
           try viewContext.save()
       }
       catch {
           let err = error as NSError
           fatalError("\(err)")
       }
   }
}

