import SwiftUI
import CoreData

struct ListView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath:
        \Animal.name, ascending: true)], animation: .default)
    private var animals: FetchedResults<Animal>
    
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath:
        \Type.name, ascending: true)], animation: .default)
    private var types: FetchedResults<Type>
    
    @GestureState var isLongPress = false
    
    var body: some View {

        let longPress = LongPressGesture()
            .updating(self.$isLongPress){value,state,transaction in
            state = value
        }
        
        return VStack{

            Spacer()
            Text("Nasze zwierzeta")
                .padding()
                .font(isLongPress ? .headline : .largeTitle)
                .gesture(longPress)
            
            List{
                Section(header: Text("Psy").font(.title)){
                ForEach(animals){animal in
                    if animal.type == "Pies"{
                        NavigationLink(
                            destination: editAnimalView(animal:animal), label: {
                                Text(animal.name!)
                                Spacer()
                                Text(animal.breed!)
                                    .font(.callout)
                            })
                    }}
                .onDelete(perform: self.deleteAnimal)
                }
                
                Section(header: Text("Koty").font(.title)){
                ForEach(animals){animal in
                    if animal.type == "Kot"{
                        NavigationLink(
                            destination: editAnimalView(animal:animal), label: {
                                Text(animal.name!)
                                Spacer()
                                Text(animal.breed!)
                                    .font(.callout)
                            })}
                }
                .onDelete(perform: self.deleteAnimal)
                }
                
                Section(header: Text("Inne").font(.title)){
                ForEach(animals){animal in
                    if animal.type == "Inne"{
                        NavigationLink(
                            destination: editAnimalView(animal:animal), label: {
                                Text(animal.name!)
                                Spacer()
                                Text(animal.breed!)
                                    .font(.callout)
                            })}
                }
                .onDelete(perform: self.deleteAnimal)
                }
            }
            .padding()
            .listStyle(PlainListStyle())
            .navigationBarTitle("Lista zwierzat",displayMode: .inline)
            .navigationBarItems(
                trailing:NavigationLink("Dodaj", destination: addAnimalView()))
            }
    }
   
    
    private func deleteAnimal(offset: IndexSet){
       withAnimation{
           offset.map{ animals[$0]}.forEach(viewContext.delete)
           
           do {
               try viewContext.save()
           }
           catch {
               let err = error as NSError
               fatalError("\(err)")
           }
       }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
}
