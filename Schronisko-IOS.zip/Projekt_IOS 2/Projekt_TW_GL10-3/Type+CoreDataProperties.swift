//
//  Type+CoreDataProperties.swift
//  Projekt_TW_GL10
//
//  Created by student on 19/06/2022.
//  Copyright © 2022 pl. All rights reserved.
//
//

import Foundation
import CoreData


extension Type {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Type> {
        return NSFetchRequest<Type>(entityName: "Type")
    }

    @NSManaged public var name: String?
    @NSManaged public var animals: NSSet?

}

// MARK: Generated accessors for animals
extension Type {

    @objc(addAnimalsObject:)
    @NSManaged public func addToAnimals(_ value: Animal)

    @objc(removeAnimalsObject:)
    @NSManaged public func removeFromAnimals(_ value: Animal)

    @objc(addAnimals:)
    @NSManaged public func addToAnimals(_ values: NSSet)

    @objc(removeAnimals:)
    @NSManaged public func removeFromAnimals(_ values: NSSet)

}

extension Type : Identifiable {

}
