W celu uruchomienia programu w Visual Studio Code:
1.Otworzyć folder zawierający client oraz server - ProjektSzkieletyProgramistyczne poprzez VSCode
2.Uruchomić nowy terminal i podzielić go
3.W jednym terminalu wydać polecenie "cd .\server\", w drugim "cd .\client\"
4.W obu terminalach wydać polecenie npm i
5.W obu terminalach wydać polecenie npm start