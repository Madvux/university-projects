IntelliJ config:
https://download2.gluonhq.com/openjfx/19/openjfx-19_windows-x64_bin-sdk.zip
Run -> Edit Configurations... -> VM options -> --module-path "path\javafx-sdk-19\lib" --add-modules javafx.controls,javafx.fxml
File -> Project Structure... -> Libraries -> + -> path\javafx-sdk-19\lib
SDK 18 languange level 17
Project requires running MySQL server with created "projekt_java" database
Project requires running MySQL server with created "projekt_java_test" database
Before running text comment "CommandLineRunner" in ZpwjApplication.class

