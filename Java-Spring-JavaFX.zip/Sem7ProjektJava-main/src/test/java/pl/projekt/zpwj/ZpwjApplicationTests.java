package pl.projekt.zpwj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZpwjApplicationTests {

	@Test
	void contextLoads() {
	}

}
